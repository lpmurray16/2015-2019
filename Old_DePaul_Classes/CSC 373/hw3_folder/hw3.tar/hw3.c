/* CSC 373 Sections 601, 610 Spring 2018
   Implement each of the 5 functions below (1.5 each).
   They should all be in 1 file, called hw3.c -- there
   should NOT be a main function in your submission.

   Also submit the written portion of the assignment (2.5 points).
*/

int strcmp373(char str1[], char str2[]) {
  return 0;  // replace this
}

char *strcat373(char dest[], char src[]) {
  // add code here


  return dest; 
}

char *strchr373(char str[], char c) {
  return str; // replace this
}

char *strncpy373(char dest[], char src[], int n) {
  // add code here

 
  return dest;
}

char *strncat373(char dest[], char src[], int n) {
  return dest;  // replace this
} 
