#!/bin/bash
logfile="log.txt"
UDS_PATH="udslogger"
./myloggerd $logfile $UDS_PATH
